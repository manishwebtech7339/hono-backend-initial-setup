import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// -------------------- TABLES --------------------
// ---- Users ----
export const usersDBTable = pgTable("users", {
  id: text("id")
    .primaryKey()
    .$default(() => crypto.randomUUID()),
  createdAt: timestamp("created_at")
    .$defaultFn(() => /* @__PURE__ */ new Date())
    .notNull(),
  updatedAt: timestamp("updated_at")
    .$defaultFn(() => /* @__PURE__ */ new Date())
    .notNull(),

  name: text("name").notNull(),
  age: integer("age").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
});

// -------------------- RELATIONS --------------------

// -------------------- ZOD Schemas --------------------
export const signUpUserDBSchema = createInsertSchema(usersDBTable);

// -------------------- TYPE --------------------
export type SignUpUserDBEntity = typeof usersDBTable.$inferInsert;
