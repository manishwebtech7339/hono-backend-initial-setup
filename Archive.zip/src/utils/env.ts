import dotenv from "dotenv";
dotenv.config();

const envVariables = {
  PORT: Number(process.env.PORT || 5002),
  JWT_SECRET: process.env.JWT_SECRET,
  DATABASE_URL: process.env.DATABASE_URL,
  CURRENT_NODE_ENV: process.env.CURRENT_NODE_ENV,
};
export default envVariables;
