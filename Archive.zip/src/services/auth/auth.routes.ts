import { Hono } from "hono";
import { signUpUserDBSchema, usersDBTable } from "../../db/schema.js";
import {
  errorResponse,
  MESSAGES,
  successResponse,
} from "../../utils/responseHelper.js";
import { db } from "../../db/index.js";
import { eq } from "drizzle-orm";
import { sign } from "hono/jwt";
import envVariables from "../../utils/env.js";
import {
  compareHashPassword,
  createHashPassword,
} from "../../utils/passwordManager.js";
import z from "zod";

const authRoutes = new Hono();

// Sign-up
authRoutes.post("/sign-up", async (c) => {
  const requestData = await c.req.json();

  // Validate
  const payload = signUpUserDBSchema.parse(requestData);

  // Check exist user
  const checkUser = await db
    .select()
    .from(usersDBTable)
    .where(eq(usersDBTable.email, payload.email));
  if (checkUser?.[0]?.id) {
    return errorResponse(c, MESSAGES.BAD_REQUEST, 404, {
      message: "User Already exist with this email",
    });
  }

  // Encrypt user password
  const password = await createHashPassword(payload.password);

  // Create user
  const user = await db
    .insert(usersDBTable)
    .values({
      name: payload.name,
      age: payload.age,
      email: payload.email,
      password: password,
    })
    .returning();
  if (!user?.[0]?.id) {
    return errorResponse(c, MESSAGES.BAD_REQUEST, 404, {
      message: "User not created",
    });
  }

  // Create user token
  const tokenPayload = {
    id: user?.[0]?.id,
    name: payload.name,
    age: payload.age,
    email: payload.email,
  };
  const token = await sign(tokenPayload, envVariables.JWT_SECRET!);

  // Send otp to user
  return successResponse(
    c,
    MESSAGES.CREATED,
    {
      user: tokenPayload,
      token,
    },
    201
  );
});

// Sign-in
authRoutes.post("/sign-in", async (c) => {
  const payload = await c.req.json();

  // Validate
  const payloadData = z
    .object({ email: z.string(), password: z.string() })
    .parse(payload);

  // Check exist user
  const checkUser = (
    await db
      .select()
      .from(usersDBTable)
      .where(eq(usersDBTable.email, payloadData.email))
  )?.[0];
  if (!checkUser) {
    return errorResponse(c, MESSAGES.BAD_REQUEST, 404);
  }

  // Match password
  const matchPassword = await compareHashPassword(
    payloadData.password,
    checkUser.password
  );
  if (!matchPassword) {
    return errorResponse(c, MESSAGES.BAD_REQUEST, 404);
  }

  // --
  return successResponse(
    c,
    MESSAGES.FETCHED,
    {
      id: checkUser.id,
      name: checkUser.name,
      age: checkUser.age,
      email: checkUser.email,
    },
    200
  );
});

export default authRoutes;
