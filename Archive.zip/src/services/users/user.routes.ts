import { Hono } from "hono";

const userRoutes = new Hono();

// Get

export default userRoutes;
